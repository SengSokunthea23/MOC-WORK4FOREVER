import React from "react";
function HomeStrap() {
    return(
        <>
        <div className="home__strapContainer___2MUkj container">
            <div className="home__agreementsStrap___1NcbI">
                <div className="responsive__column___-eDX6 responsive__container___3NIjF">
                    <h2 className="home__linksHeading___128LB typography__h1___3cURI ">
                    Explore by Market
                    </h2>
                    <div className="responsive__row___14KPq">
                        <ul className="home__agreements___1OBpq form__unstyled-list___1N7D1 d-flex">
                            <li className="home__agreementColumn___1Yrra responsive__column___-eDX6"> 
                            <a className="home__agreement___3A-iP">
                                <div className="home__agreementImg___1jlqB">
                                    <img src="usa.jpg" alt="best"/>
                                </div>
                                <div className="home__agreementLinkBar___DlWnt typography__unlimited-sans-medium___3jRjW text-center">
                                India
                                </div>
                            </a>
                            </li>
                            <li className="home__agreementColumn___1Yrra responsive__column___-eDX6">
                            <a className="home__agreement___3A-iP">
                                <div className="home__agreementImg___1jlqB">
                                    <img src="usa.jpg" alt="best"/>
                                </div>
                                <div className="home__agreementLinkBar___DlWnt typography__unlimited-sans-medium___3jRjW text-center">
                                India
                                </div>
                            </a>
                            </li>
                            <li className="home__agreementColumn___1Yrra responsive__column___-eDX6">
                            <a className="home__agreement___3A-iP">
                                <div className="home__agreementImg___1jlqB">
                                    <img src="usa.jpg" alt="best"/>
                                </div>
                                <div className="home__agreementLinkBar___DlWnt typography__unlimited-sans-medium___3jRjW text-center">
                                India
                                </div>
                            </a>
                            </li>
                        </ul>
                    </div>
                    <div className="responsive__row___14KPq">
                    <ul className="home__agreements___1OBpq form__unstyled-list___1N7D1 d-flex">
                    <li className="home__agreementColumn___1Yrra responsive__column___-eDX6">
                            <a className="home__agreement___3A-iP">
                                <div className="home__agreementImg___1jlqB">
                                    <img src="usa.jpg" alt="best"/>
                                </div>
                                <div className="home__agreementLinkBar___DlWnt typography__unlimited-sans-medium___3jRjW text-center">
                                India
                                </div>
                            </a>
                            </li>
                            <li className="home__agreementColumn___1Yrra responsive__column___-eDX6">
                            <a className="home__agreement___3A-iP">
                                <div className="home__agreementImg___1jlqB">
                                    <img src="usa.jpg" alt="best"/>
                                </div>
                                <div className="home__agreementLinkBar___DlWnt typography__unlimited-sans-medium___3jRjW text-center">
                                India
                                </div>
                            </a>
                            </li>
                            <li className="home__agreementColumn___1Yrra responsive__column___-eDX6">
                            <a className="home__agreement___3A-iP">
                                <div className="home__agreementImg___1jlqB">
                                    <img src="usa.jpg" alt="best"/>
                                </div>
                                <div className="home__agreementLinkBar___DlWnt typography__unlimited-sans-medium___3jRjW text-center">
                                India
                                </div>
                            </a>
                            </li>
                            </ul>
                </div>
                </div>
            </div>
        </div>
        </>
    )
}
export default HomeStrap;